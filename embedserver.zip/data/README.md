# What is this folder

This folder contains the configuration files needed for the server to run.
**NOTE:** Keep these files private and secure!

* `database/`
  * The NEDB database
* `config.yml`
  * The configuration file
* `debug.log`
  * The server logs
