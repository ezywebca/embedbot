import Theme from '../../types/theme'

interface Server {
  id: string
  theme: Theme
}

export default Server
