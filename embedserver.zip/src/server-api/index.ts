import { EventEmitter } from 'events'

const events = new EventEmitter()

export default events
